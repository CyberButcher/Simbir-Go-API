﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Simbir_GO_Api.Helpers;
using Simbir_GO_Api.Interfaces;

namespace Simbir_GO_Api.Services
{
    public class AccountService : IAccountService
    {
        private readonly MyDBContext _dbContext;
        public AccountService(MyDBContext dbContext) 
        {
            _dbContext = dbContext;
        }
        public Task<IActionResult> SignIn([FromForm] string username, [FromForm] string password)
        {
            var user = _dbContext.Users.SingleOrDefault(u => (u.UserName == username));

            if (user != null && HashForPass.VerifyHashedPassword(user.Password, password))
            {
                return new Ok(new { Token = JWTService.GenerateJWT(user) });
            }

            return BadRequest("Неверное имя пользователя или пароль");
        }

        public IActionResult SignOut()
        {
            throw new NotImplementedException();
        }

        public IActionResult SignUp([FromForm] string username, [FromForm] string password)
        {
            throw new NotImplementedException();
        }

        public IActionResult UpdateAccount([FromForm(Name = "oldUsername")] string? oldUsername = null, [FromForm(Name = "newUsername")] string? newUsername = null, [FromForm(Name = "oldPassword")] string? oldPassword = null, [FromForm(Name = "newPassword")] string? newPassword = null)
        {
            throw new NotImplementedException();
        }
    }
}
