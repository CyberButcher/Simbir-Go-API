﻿namespace Simbir_GO_Api.Helpers
{
    public class Config
    {
        public static string SecretKey { get; set; }
        public static string ConnectionString { get; set;} 
    }
}
