﻿using Microsoft.AspNetCore.Mvc;

namespace Simbir_GO_Api.Interfaces
{
    public interface IAccountService
    {
        public Task<IActionResult> SignIn([FromForm] string username, [FromForm] string password);
        public Task<IActionResult> SignUp([FromForm] string username, [FromForm] string password);
        public Task<IActionResult> SignOut();
        public Task<IActionResult> UpdateAccount(
            [FromForm(Name = "oldUsername")] string? oldUsername = null,
            [FromForm(Name = "newUsername")] string? newUsername = null,
            [FromForm(Name = "oldPassword")] string? oldPassword = null,
            [FromForm(Name = "newPassword")] string? newPassword = null);
    }
}
